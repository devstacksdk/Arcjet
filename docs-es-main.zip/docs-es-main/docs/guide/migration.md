# Migración de v7

Si estás migrando desde `rolldown-vite`, la versión de vista técnica para Vite integrado con Rolldown para v6 & v7, solo las secciones con <Badge text="NRV" type="warning" /> en el título son aplicables.

## Cambio en los Navegadores de Destino Predeterminados [<Badge text="NRV" type="warning" />](#migration-from-v7)

El valor de los navegadores predeterminados de `build.target` y `'baseline-widely-available'` se actualiza a versiones más recientes del navegador:

- Chrome 107 → 111
- Edge 107 → 111
- Firefox 104 → 114
- Safari 16.0 → 16.4

Estas versiones de navegador se alinean con los conjuntos de características [Baseline Widely Available](https://web-platform-dx.github.io/baseline/) a partir de 2026-01-01. En otras palabras, fueron lanzadas hace aproximadamente dos años y medio.

## Rolldown

Vite 8 utiliza herramientas basadas en [Rolldown](https://rolldown.rs/) y [Oxc](https://oxc.rs/) en lugar de [esbuild](https://esbuild.github.io/) y [Rollup](https://rollupjs.org/).

### Migración Gradual

El paquete `rolldown-vite` implementa Vite 7 con Rolldown, sin otros cambios de Vite 8. Esto puede ser utilizado como un paso intermedio para migrar a Vite 8. Véase [la guía de integración de Rolldown](./rolldown.md) en los documentos de Vite 7 para cambiar a `rolldown-vite` desde Vite 7.

Para los usuarios que migran de `rolldown-vite` a Vite 8, puedes deshacer los cambios de dependencia en `package.json` y actualizar a Vite 8:

```json
{
  "devDependencies": {
    "vite": "npm:rolldown-vite@7.2.2" // [!code --]
    "vite": "^8.0.0" // [!code ++]
  }
}
```

### El Optimizador de Dependencias Ahora Usa Rolldown

Rolldown ahora se utiliza para la optimización de dependencias en lugar de esbuild. Vite todavía soporta [`optimizeDeps.esbuildOptions`](/config/dep-optimization-options#optimizedeps-esbuildoptions) para compatibilidad con versiones anteriores, convirtiéndolo automáticamente a [`optimizeDeps.rolldownOptions`](/config/dep-optimization-options#optimizedeps-rolldownoptions). `optimizeDeps.esbuildOptions` ahora está obsoleto y se eliminará en el futuro, y te animamos a migrar a `optimizeDeps.rolldownOptions`.

Las siguientes opciones se convierten automáticamente:

- [`esbuildOptions.minify`](https://esbuild.github.io/api/#minify) -> [`rolldownOptions.output.minify`](https://rolldown.rs/reference/OutputOptions.minify)
- [`esbuildOptions.treeShaking`](https://esbuild.github.io/api/#tree-shaking) -> [`rolldownOptions.treeshake`](https://rolldown.rs/reference/InputOptions.treeshake)
- [`esbuildOptions.define`](https://esbuild.github.io/api/#define) -> [`rolldownOptions.transform.define`](https://rolldown.rs/reference/InputOptions.transform#define)
- [`esbuildOptions.loader`](https://esbuild.github.io/api/#loader) -> [`rolldownOptions.moduleTypes`](https://rolldown.rs/reference/InputOptions.moduleTypes)
- [`esbuildOptions.preserveSymlinks`](https://esbuild.github.io/api/#preserve-symlinks) -> [`!rolldownOptions.resolve.symlinks`](https://rolldown.rs/reference/InputOptions.resolve#symlinks)
- [`esbuildOptions.resolveExtensions`](https://esbuild.github.io/api/#resolve-extensions) -> [`rolldownOptions.resolve.extensions`](https://rolldown.rs/reference/InputOptions.resolve#extensions)
- [`esbuildOptions.mainFields`](https://esbuild.github.io/api/#main-fields) -> [`rolldownOptions.resolve.mainFields`](https://rolldown.rs/reference/InputOptions.resolve#mainfields)
- [`esbuildOptions.conditions`](https://esbuild.github.io/api/#conditions) -> [`rolldownOptions.resolve.conditionNames`](https://rolldown.rs/reference/InputOptions.resolve#conditionnames)
- [`esbuildOptions.keepNames`](https://esbuild.github.io/api/#keep-names) -> [`rolldownOptions.output.keepNames`](https://rolldown.rs/reference/OutputOptions.keepNames)
- [`esbuildOptions.platform`](https://esbuild.github.io/api/#platform) -> [`rolldownOptions.platform`](https://rolldown.rs/reference/InputOptions.platform)
- [`esbuildOptions.plugins`](https://esbuild.github.io/plugins/) -> [`rolldownOptions.plugins`](https://rolldown.rs/reference/InputOptions.plugins) (soporte parcial)

Puedes obtener las opciones establecidas por la capa de compatibilidad desde el hook `configResolved`:

```js
const plugin = {
  name: 'log-config',
  configResolved(config) {
    console.log('options', config.optimizeDeps.rolldownOptions)
  },
},
```

### Transformaciones de JavaScript por Oxc

Oxc ahora se utiliza para la transformación de JavaScript en lugar de esbuild. Vite todavía soporta la opción [`esbuild`](/config/shared-options#esbuild) para compatibilidad con versiones anteriores, convirtiéndola automáticamente a [`oxc`](/config/shared-options#oxc). `esbuild` ahora está obsoleto y se eliminará en el futuro, por lo que te animamos a migrar a `oxc`.

Las siguientes opciones se convierten automáticamente:

- `esbuild.jsxInject` -> `oxc.jsxInject`
- `esbuild.include` -> `oxc.include`
- `esbuild.exclude` -> `oxc.exclude`
- [`esbuild.jsx`](https://esbuild.github.io/api/#jsx) -> [`oxc.jsx`](https://oxc.rs/docs/guide/usage/transformer/jsx)
  - `esbuild.jsx: 'preserve'` -> `oxc.jsx: 'preserve'`
  - `esbuild.jsx: 'automatic'` -> `oxc.jsx: { runtime: 'automatic' }`
    - [`esbuild.jsxImportSource`](https://esbuild.github.io/api/#jsx-import-source) -> `oxc.jsx.importSource`
  - `esbuild.jsx: 'transform'` -> `oxc.jsx: { runtime: 'classic' }`
    - [`esbuild.jsxFactory`](https://esbuild.github.io/api/#jsx-factory) -> `oxc.jsx.pragma`
    - [`esbuild.jsxFragment`](https://esbuild.github.io/api/#jsx-fragment) -> `oxc.jsx.pragmaFrag`
  - [`esbuild.jsxDev`](https://esbuild.github.io/api/#jsx-dev) -> `oxc.jsx.development`
  - [`esbuild.jsxSideEffects`](https://esbuild.github.io/api/#jsx-side-effects) -> `oxc.jsx.pure`
- [`esbuild.define`](https://esbuild.github.io/api/#define) -> [`oxc.define`](https://oxc.rs/docs/guide/usage/transformer/global-variable-replacement#define)
- [`esbuild.banner`](https://esbuild.github.io/api/#banner) -> plugin personalizado usando el hook transform
- [`esbuild.footer`](https://esbuild.github.io/api/#footer) -> plugin personalizado usando el hook transform

La opción [`esbuild.supported`](https://esbuild.github.io/api/#supported) no es soportada por Oxc. Si necesitas esta opción, por favor consulta [oxc-project/oxc#15373](https://github.com/oxc-project/oxc/issues/15373).

Puedes obtener las opciones establecidas por la capa de compatibilidad desde el hook `configResolved`:

```js
const plugin = {
  name: 'log-config',
  configResolved(config) {
    console.log('options', config.oxc)
  },
},
```

<!-- TODO: add link to rolldownOptions.output.minify -->

Actualmente, el transformador Oxc no admite la reducción de decoradores nativos mientras esperamos que la especificación avance, vea ([oxc-project/oxc#9170](https://github.com/oxc-project/oxc/issues/9170)).

:::: details Solución alternativa para reducir decoradores nativos

Puedes usar [Babel](https://babeljs.io/) o [SWC](https://swc.rs/) para reducir decoradores nativos por el momento.

**Usando Babel:**

::: code-group

```bash [npm]
$ npm install -D @rolldown/plugin-babel @babel/plugin-proposal-decorators
```

```bash [Yarn]
$ yarn add -D @rolldown/plugin-babel @babel/plugin-proposal-decorators
```

```bash [pnpm]
$ pnpm add -D @rolldown/plugin-babel @babel/plugin-proposal-decorators
```

```bash [Bun]
$ bun add -D @rolldown/plugin-babel @babel/plugin-proposal-decorators
```

```bash [Deno]
$ deno add -D npm:@rolldown/plugin-babel npm:@babel/plugin-proposal-decorators
```

:::

```ts [vite.config.ts]
import { defineConfig } from 'vite'
import babel from '@rolldown/plugin-babel'

function decoratorPreset(options: Record<string, unknown>) {
  return {
    preset: () => ({
      plugins: [['@babel/plugin-proposal-decorators', options]],
    }),
    rolldown: {
      // Ejecuta esta transformación solo si el archivo contiene un decorador.
      filter: {
        code: '@',
      },
    },
  }
}

export default defineConfig({
  plugins: [babel({ presets: [decoratorPreset({ version: '2023-11' })] })],
})
```

**Usando SWC:**

::: code-group

```bash [npm]
$ npm install -D @rollup/plugin-swc @swc/core
```

```bash [Yarn]
$ yarn add -D @rollup/plugin-swc @swc/core
```

```bash [pnpm]
$ pnpm add -D @rollup/plugin-swc @swc/core
```

```bash [Bun]
$ bun add -D @rollup/plugin-swc @swc/core
```

```bash [Deno]
$ deno add -D npm:@rollup/plugin-swc npm:@swc/core
```

:::

```js
import { defineConfig, withFilter } from 'vite'
import swc from '@rollup/plugin-swc'

export default defineConfig({
  // ...
  plugins: [
    withFilter(
      swc({
        swc: {
          jsc: {
            parser: { decorators: true, decoratorsBeforeExport: true },
            transform: { decoratorVersion: '2023-11' },
          },
        },
      }),
      // Ejecuta esta transformación solo si el archivo contiene un decorador.
      { transform: { code: '@' } },
    ),
  ],
})
```

::::

#### Alternativas a esbuild

`esbuild` ya no es utilizado directamente por Vite y ahora es una dependencia opcional. Si estás usando un plugin que utiliza la función `transformWithEsbuild`, necesitas instalar `esbuild` como una `devDependency`. La función `transformWithEsbuild` está obsoleta y será eliminada en el futuro. Recomendamos migrar a la nueva función `transformWithOxc`.

### Minificación de JavaScript por Oxc

El Minificador de Oxc ahora se utiliza para la minificación de JavaScript en lugar de esbuild. Puedes usar la opción obsoleta [`build.minify: 'esbuild'`](/config/build-options#build-minify) para volver a esbuild. Esta opción de configuración será eliminada en el futuro y necesitas instalar `esbuild` como una `devDependency` ya que Vite ya no depende directamente de esbuild.

Si estabas usando las opciones `esbuild.minify*` para controlar el comportamiento de la minificación, ahora puedes usar `build.rolldownOptions.output.minify` en su lugar. Si estabas usando la opción `esbuild.drop`, ahora puedes usar las opciones [`build.rolldownOptions.output.minify.compress.drop*`](https://oxc.rs/docs/guide/usage/minifier/dead-code-elimination).

El obfuscado de propiedades y sus opciones relacionadas ([`mangleProps`, `reserveProps`, `mangleQuoted`, `mangleCache`](https://esbuild.github.io/api/#mangle-props)) no son compatibles con Oxc. Si necesitas estas opciones, consulta [oxc-project/oxc#15375](https://github.com/oxc-project/oxc/issues/15375).

esbuild y el Minificador de Oxc hacen suposiciones ligeramente diferentes sobre el código fuente. En caso de que sospeches que el minificador está causando problemas en tu código, puedes comparar estas suposiciones aquí:

- [Suposiciones de minificación de esbuild](https://esbuild.github.io/api/#minify-considerations)
- [Suposiciones del Minificador de Oxc](https://github.com/oxc-project/oxc/blob/main/crates/oxc_minifier/docs/ASSUMPTIONS.md)

Por favor, informa cualquier problema que encuentres relacionado con la minificación en tus aplicaciones JavaScript.

### Minificación de CSS con Lightning CSS

[Lightning CSS](https://lightningcss.dev/) ahora se utiliza para la minificación de CSS por defecto. Puedes usar la opción [`build.cssMinify: 'esbuild'`](/config/build-options#build-cssminify) para volver a esbuild. Ten en cuenta que necesitas instalar `esbuild` como una `devDependency`.

Lightning CSS admite una mejor sintaxis de lowering y el tamaño de tu paquete CSS podría aumentar ligeramente.

### Interoperabilidad consistente de CommonJS

La importación `default` de un módulo CommonJS (CJS) ahora se maneja de manera consistente.

Si coincide con una de las siguientes condiciones, la importación `default` es el valor `module.exports` del módulo CJS importado. De lo contrario, la importación `default` es el valor `module.exports.default` del módulo CJS importado:

- El importador es `.mjs` o `.mts`.
- El `package.json` más cercano para el importador tiene un campo `type` establecido en `module`.
- El valor `module.exports.__esModule` del módulo CJS importado no está establecido en `true`.

::: details El comportamiento anterior

En desarrollo, si coincidía con una de las siguientes condiciones, la importación `default` era el valor `module.exports` del módulo CJS importado. De lo contrario, la importación `default` era el valor `module.exports.default` del módulo CJS importado:

- _El importador está incluido en la optimización de dependencias_ y `.mjs` o `.mts`.
- _El importador está incluido en la optimización de dependencias_ y el `package.json` más cercano para el importador tiene un campo `type` establecido en `module`.
- El valor `module.exports.__esModule` del módulo CJS importado no está establecido en `true`.

En build, las condiciones eran:

- El valor `module.exports.__esModule` del módulo CJS importado no está establecido en `true`.
- _La propiedad `default` de `module.exports` no existe_.

(asumiendo que [`build.commonjsOptions.defaultIsModuleExports`](https://github.com/rollup/plugins/tree/master/packages/commonjs#defaultismoduleexports) no se ha cambiado del valor predeterminado `'auto'`)

:::

Consulta la documentación de Rolldown sobre este problema para obtener más detalles: [Importación `default` ambigua de módulos CJS - Bundling CJS | Rolldown](https://rolldown.rs/in-depth/bundling-cjs#ambiguous-default-import-from-cjs-modules).

Este cambio puede romper algún código existente que importe módulos CJS. Puedes usar la opción obsoleta `legacy.inconsistentCjsInterop: true` para restaurar temporalmente el comportamiento anterior. Si encuentras un paquete que se ve afectado por este cambio, por favor infórmalo al autor del paquete o envíale un pull request. Asegúrate de enlazar a la [documentación de Rolldown](https://rolldown.rs/in-depth/bundling-cjs#ambiguous-default-import-from-cjs-modules) anterior para que el autor pueda entender el contexto.

### Eliminación de la Resolución de Módulos Utilizando la Inferencia de Formato

Cuando tanto los campos `browser` como `module` están presentes en `package.json`, Vite solía resolver el campo basándose en el contenido del archivo y solía elegir el archivo ESM para los navegadores. Esto se introdujo porque algunos paquetes estaban usando el campo `module` para apuntar a archivos ESM para Node.js y otros paquetes estaban usando el campo `browser` para apuntar a archivos UMD para navegadores. Dado que el campo moderno `exports` solucionó este problema y ahora es adoptado por muchos paquetes, Vite ya no usa esta heurística y siempre respeta el orden de la opción [`resolve.mainFields`](/config/shared-options#resolve-mainfields). Si estabas confiando en este comportamiento, puedes usar la opción [`resolve.alias`](/config/shared-options#resolve-alias) para mapear el campo al archivo deseado o aplicar un parche con tu gestor de paquetes (ej. `patch-package`, `pnpm patch`).

### Llamadas Require Para Módulos Externalizados

Las llamadas `require` para módulos externalizados ahora se preservan como llamadas `require` y no se convierten en declaraciones `import`. Esto es para preservar la semántica de las llamadas `require`. Si quieres convertirlas en declaraciones `import`, puedes usar el [plugin incorporado de Rolldown `esmExternalRequirePlugin`](https://rolldown.rs/builtin-plugins/esm-external-require), que se reexporta desde `vite`.

```js
import { defineConfig, esmExternalRequirePlugin } from 'vite'

export default defineConfig({
  // ...
  plugins: [
    esmExternalRequirePlugin({
      external: ['react', 'vue', /^node:/],
    }),
  ],
})
```

Consulta la documentación de Rolldown para obtener más detalles: [`require` módulos externos - Bundling CJS | Rolldown](https://rolldown.rs/in-depth/bundling-cjs#require-external-modules).

### `import.meta.url` en UMD / IIFE

`import.meta.url` ya no se polifiliza en los formatos de salida UMD / IIFE. Se reemplazará con `undefined` por defecto. Si prefieres el comportamiento anterior, puedes usar la opción [`define`](/config/shared-options#define) con la opción [`build.rolldownOptions.output.intro`](https://rolldown.rs/reference/OutputOptions.intro). Consulta la documentación de Rolldown para más detalles: [Propiedades `import.meta` conocidas - Formatos de salida no ESM | Rolldown](https://rolldown.rs/in-depth/non-esm-output-formats#well-known-import-meta-properties).

### Eliminación de la opción `build.rollupOptions.watch.chokidar`

La opción `build.rollupOptions.watch.chokidar` se eliminó. Por favor, migra a la opción [`build.rolldownOptions.watch.watcher`](https://rolldown.rs/reference/InputOptions.watch#watcher).

### Eliminación de la forma de objeto de `build.rollupOptions.output.manualChunks` y deprecación de la forma de función

La opción de forma de objeto `output.manualChunks` ya no es compatible. La forma de función `output.manualChunks` está obsoleta. Rolldown tiene la opción [`codeSplitting`](https://rolldown.rs/reference/OutputOptions.codeSplitting) más flexible. Consulta la documentación de Rolldown para más detalles sobre `codeSplitting`: [Manual Code Splitting - Rolldown](https://rolldown.rs/in-depth/manual-code-splitting).

### `build()` lanza `BundleError`

_Este cambio solo afecta a los usuarios de la API de JS._

`build()` ahora lanza un [`BundleError`](https://rolldown.rs/reference/TypeAlias.BundleError) en lugar del error sin procesar lanzado en el plugin. `BundleError` está tipado como `Error & { errors?: RolldownError[] }` y envuelve los errores individuales en un arreglo `errors`. Si necesitas los errores individuales, debes acceder a `.errors`:

```js
try {
  await build()
} catch (e) {
  if (e.errors) {
    for (const error of e.errors) {
      console.log(error.code) // error code
    }
  }
}
```

### Soporte y Detección Automática de Tipos de Módulo

_Este cambio solo afecta a los autores de plugins._

Rolldown tiene soporte experimental para [Tipos de módulo](https://rolldown.rs/guide/notable-features#module-types), similar a la [opción `loader` de esbuild](https://esbuild.github.io/api/#loader). Debido a esto, Rolldown establece automáticamente un tipo de módulo basado en la extensión del id resuelto. Si estás convirtiendo contenido de otros tipos de módulo a JavaScript en los hooks `load` o `transform`, es posible que necesites agregar `moduleType: 'js'` al valor devuelto:

```js
const plugin = {
  name: 'txt-loader',
  load(id) {
    if (id.endsWith('.txt')) {
      const content = fs.readFile(id, 'utf-8')
      return {
        code: `export default ${JSON.stringify(content)}`,
        moduleType: 'js', // [!code ++]
      }
    }
  },
}
```

### Otras Deprecaciones Relacionadas

Las siguientes opciones están obsoletas y se eliminarán en el futuro:

- `build.rollupOptions`: renombrado a `build.rolldownOptions`
- `worker.rollupOptions`: renombrado a `worker.rolldownOptions`
- `build.commonjsOptions`: ahora no hace nada
- `build.dynamicImportVarsOptions.warnOnError`: ahora no hace nada
- `resolve.alias[].customResolver`: Usa un plugin personalizado con el hook `resolveId` y `enforce: 'pre'` en su lugar

## Características Obsoletas Eliminadas [<Badge text="NRV" type="warning" />](#migration-from-v7)

- Pasar una URL a `import.meta.hot.accept` ya no es compatible. Por favor, pasa un id en su lugar. ([#21382](https://github.com/vitejs/vite/pull/21382))

## Avanzado

Estos cambios rotóricos se espera que afecten solo a una minoría de casos de uso:

- [Extglobs](https://github.com/micromatch/picomatch/blob/master/README.md#extglobs) aún no son compatibles ([rolldown-vite#365](https://github.com/vitejs/rolldown-vite/issues/365))
- El espacio de nombres heredado de TypeScript solo se admite parcialmente. Consulta la [documentación relacionada del Transformador Oxc](https://oxc.rs/docs/guide/usage/transformer/typescript.html#partial-namespace-support) para más detalles.
- `define` no comparte referencias para objetos: Cuando pasas un objeto como valor a `define`, cada variable tendrá una copia separada del objeto. Consulta el [documento del Transformador Oxc](https://oxc.rs/docs/guide/usage/transformer/global-variable-replacement#define) para más detalles.
- Cambios en el objeto `bundle` (`bundle` es un objeto pasado en los hooks `generateBundle` / `writeBundle`, devuelto por la función `build`):
  - Asignar a `bundle[foo]` no es compatible. Rollup tampoco recomienda esto. Por favor, usa `this.emitFile()` en su lugar.
  - La referencia no se comparte entre los hooks ([rolldown-vite#410](https://github.com/vitejs/rolldown-vite/issues/410))
- Todos los hooks paralelos en Rollup funcionan como hooks secuenciales. Consulta la [documentación de Rolldown](https://rolldown.rs/apis/plugin-api#sequential-hook-execution) para más detalles.
- `"use strict";` no se inyecta a veces. Consulta la [documentación de Rolldown](https://rolldown.rs/in-depth/directives) para más detalles.
- La transformación a ES5 y versiones inferiores con plugin-legacy no es compatible ([rolldown-vite#452](https://github.com/vitejs/rolldown-vite/issues/452))
- Pasar el mismo navegador con múltiples versiones a la opción `build.target` ahora produce un error: esbuild selecciona la última versión de este, lo que probablemente no era lo que pretendías.
- Falta de compatibilidad por parte de Rolldown: Las siguientes características no son compatibles con Rolldown y ya no son compatibles con Vite.
  - `build.rollupOptions.output.format: 'system'` ([rolldown#2387](https://github.com/rolldown/rolldown/issues/2387))
  - `build.rollupOptions.output.format: 'amd'` ([rolldown#2528](https://github.com/rolldown/rolldown/issues/2528))
  - Hook `shouldTransformCachedModule` ([rolldown#4389](https://github.com/rolldown/rolldown/issues/4389))
  - Hook `resolveImportMeta` ([rolldown#1010](https://github.com/rolldown/rolldown/issues/1010))
  - Hook `renderDynamicImport` ([rolldown#4532](https://github.com/rolldown/rolldown/issues/4532))
  - Hook `resolveFileUrl`
- Las funciones `parseAst` / `parseAstAsync` ahora están obsoletas en favor de las funciones `parseSync` / `parse` que ahora tienen más características.
- Los comentarios se eliminan antes del hook `renderChunk` en lugar de después del hook `renderChunk`.
- Los comentarios que no están enumerados [aquí](https://rolldown.rs/reference/OutputOptions.comments) se mueven, mientras que Rollup solo elimina los comentarios si se elimina el código adyacente.

## Migración desde v6

Ver el [Guía de Migración desde v6](/guide/migration-v6-to-v7) para ver los cambios necesarios para portar tu aplicación a Vite 7, y luego proceder con los cambios en esta página.
