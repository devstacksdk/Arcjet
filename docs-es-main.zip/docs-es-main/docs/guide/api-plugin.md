# API de Plugins

Los plugins de Vite amplían la interfaz de plugins de Rolldown con algunas opciones adicionales específicas de Vite. Como resultado, puedes escribir un plugin de Vite una vez y hacer que funcione tanto para desarrollo como para compilación.

**Se recomienda revisar primero la [documentación de plugins de Rolldown](https://rolldown.rs/apis/plugin-api) antes de leer las secciones a continuación.**

## Creación de un Plugin

Vite se esfuerza por ofrecer patrones establecidos listos para usar, así que antes de crear un nuevo plugin, asegúrate de consultar la [Guía de funcionalidades](/guide/features) para ver si tu necesidad está cubierta. Revisa también los plugins de la comunidad disponibles, tanto en forma de [plugins de Rollup compatible](https://github.com/rollup/awesome) como [plugins específicos de Vite](https://github.com/vitejs/awesome-vite#plugins).

Al crear un plugin, puedes colocarlo en tu `vite.config.js`. No hay necesidad de crear un nuevo paquete para ello. Una vez que veas que un plugin fue útil en tus proyectos, considera compartirlo para ayudar a otros [en el ecosistema](https://chat.vite.dev).

::: tip
Al aprender, depurar o crear plugins, sugerimos incluir [vite-plugin-inspect](https://github.com/antfu/vite-plugin-inspect) en tu proyecto. Este te permite inspeccionar el estado intermedio de los plugins de Vite. Después de la instalación, puedes visitar `localhost:5173/__inspect/` para inspeccionar los módulos y la pila de transformación de tu proyecto. Consulta las instrucciones de instalación en los [documentos de vite-plugin-inspect](https://github.com/antfu/vite-plugin-inspect).
![vite-plugin-inspect](../images/vite-plugin-inspect.webp)

:::

## Convenciones

Si el plugin no usa hooks específicos de Vite y se puede implementar como un [Plugin de Rolldown compatible](./api-plugin.md#compatibilidad-de-plugins-rolldown), entonces se recomienda usar las [Convenciones de nomenclatura de plugin de Rolldown](https://rolldown.rs/apis/plugin-api#conventions).

- Los plugins de Rolldown deben tener un nombre claro con el prefijo `rolldown-plugin-`.
- Incluye las palabras clave `rolldown-plugin` y `vite-plugin` en el campo `keywords` de package.json.

Esto expone el plugin para que también se use en proyectos basados ​​en Rolldown o Rollup puros.

Solo para plugins de Vite

- Los plugins de Vite deben tener un nombre claro con el prefijo `vite-plugin-`.
- Incluye la palabra clave `vite-plugin` en el campo `keywords` de package.json.
- Incluye una sección en los documentos del plugin que detalle por qué es un plugin exclusivo de Vite (por ejemplo, utiliza hooks de plugin específicos de Vite).

Si tu plugin solo funcionará para un marco de trabajo en particular, su nombre debe incluirse como parte del prefijo.

- Prefijo `vite-plugin-vue-` para Vue
- Prefijo `vite-plugin-react-` para React
- Prefijo `vite-plugin-svelte-` para plugins Svelte

Puedes ver también la [Convención de Módulos Virtuales](https://rolldown.rs/apis/plugin-api#virtual-modules).

## Configuración de Plugins

Los usuarios agregarán plugins al proyecto `devDependencies` y los configurarán usando la opción de array `plugins`.

```js [vite.config.js]
import vitePlugin from 'vite-plugin-feature'
import rollupPlugin from 'rollup-plugin-feature'

export default defineConfig({
  plugins: [vitePlugin(), rollupPlugin()],
})
```

Se ignorarán los plugins falsos, que se pueden usar para activar o desactivar plugins fácilmente.

`plugins` también acepta ajustes predefinidos que incluyen varios plugins como un solo elemento. Esto es útil para funciones complejas (como la integración de marcos) que se implementan mediante varios plugins. El array se aplanará internamente.

```js
// framework-plugin
import frameworkRefresh from 'vite-plugin-framework-refresh'
import frameworkDevtools from 'vite-plugin-framework-devtools'

export default function framework(config) {
  return [frameworkRefresh(config), frameworkDevTools(config)]
}
```

```js [vite.config.js]
import { defineConfig } from 'vite'
import framework from 'vite-plugin-framework'

export default defineConfig({
  plugins: [framework()],
})
```

## Ejemplos Simples

:::tip
Es una convención común crear un plugin Vite/Rolldown/Rollup como una función de fábrica que devuelve el objeto de plugin real. La función puede aceptar opciones que permiten a los usuarios personalizar el comportamiento del plugin.
:::

### Transformación de Tipos de Archivos Personalizados

```js
export default function myPlugin() {
  return {
    name: 'transform-file',

    transform: {
      filter: {
        id: fileRegex,
      },
      handler(src, id) {
        return {
          code: compileFileToJS(src),
          map: null, // provee un mapa de fuentes si es necesario
        }
      },
    },
  }
}
```

### Importación de un Archivo Virtual

Los módulos virtuales te permiten pasar información en tiempo de compilación a los archivos fuente usando la sintaxis normal de importación ESM. Consulta la [Convención de Módulos Virtuales](https://rolldown.rs/apis/plugin-api#virtual-modules) para conocer la convención completa.

```js
import { exactRegex } from '@rolldown/pluginutils'

export default function myPlugin() {
  const virtualModuleId = 'virtual:my-module'
  const resolvedVirtualModuleId = '\0' + virtualModuleId

  return {
    name: 'my-plugin', // requerido, aparecerá en advertencias y errores
    resolveId: {
      filter: { id: exactRegex(virtualModuleId) },
      handler() {
        return resolvedVirtualModuleId
      },
    },
    load: {
      filter: { id: exactRegex(resolvedVirtualModuleId) },
      handler() {
        return `export const msg = "from virtual module"`
      },
    },
  }
}
```

Lo que permite importar el módulo en JavaScript:

```js
import { msg } from 'virtual:my-module'

console.log(msg)
```

En Vite, dado que `\0` no es un carácter permitido en las URL de importación, un id virtual `\0{id}` termina codificado como `/@id/__x00__{id}` durante el desarrollo en el navegador. El id se decodifica antes de ingresar a la canalización de plugins, por lo que el código de hooks de plugins no lo ve.

## Hooks de Rolldown

Durante el desarrollo, el servidor de desarrollo de Vite crea un contenedor de plugins que invoca [Hooks de compilación de Rolldown](https://rolldown.rs/apis/plugin-api#build-hooks) de la misma manera que lo hace Rolldown.

Todos los hooks de Rolldown son [hooks por entorno](/guide/api-environment-plugins#hooks-por-entorno-y-hooks-globales).

Los siguientes hooks se llaman una vez en el inicio del servidor:

- [`options`](https://rolldown.rs/reference/Interface.Plugin#options)
- [`buildStart`](https://rolldown.rs/reference/Interface.Plugin#buildstart)

Los siguientes hooks se llaman en cada solicitud de módulo entrante:

- [`resolveId`](https://rolldown.rs/reference/Interface.Plugin#resolveid)
- [`load`](https://rolldown.rs/reference/Interface.Plugin#load)
- [`transform`](https://rolldown.rs/reference/Interface.Plugin#transform)

Estos hooks también tienen un parámetro `options` extendido con propiedades adicionales específicas de Vite. Puedes leer más en la [documentación de SSR](/guide/ssr.html#logica-de-plugin-especifica-de-ssr).

Algunas llamadas `resolveId` al valor `importer` pueden ser una ruta absoluta para un `index.html` genérico en la raíz, ya que no siempre es posible derivar el importador real debido al patrón de servidor de desarrollo desagregado de Vite. Para las importaciones manejadas dentro de la canalización de resolución de Vite, se puede rastrear al importador durante la fase de análisis de importación, proporcionando el valor `importer` correcto.

Los siguientes hooks se llaman cuando el servidor está cerrado:

- [`buildEnd`](https://rolldown.rs/reference/Interface.Plugin#buildend)
- [`closeBundle`](https://rolldown.rs/reference/Interface.Plugin#closebundle)

Ten en cuenta que el hook [`moduleParsed`](https://rolldown.rs/reference/Interface.Plugin#moduleparsed) **no** se llama durante el desarrollo, porque Vite evita los análisis AST completos para un mejor rendimiento.

[Los hooks de generación de salida](https://rolldown.rs/apis/plugin-api#output-generation-hooks) (excepto `closeBundle`) **no** se llaman durante el desarrollo.

## Hooks Específicos de Vite

Los plugins de Vite también pueden proporcionar hooks que sirven para propósitos específicos de Vite. Estos hooks son ignorados por Rollup.

### `config`

- **Tipo:** `(config: UserConfig, env: { mode: 'build' | 'serve', command: string, isSsrBuild?: boolean, isPreview?: boolean }) => UserConfig | null | void`
- **Clase:** `async`, `sequential`
- **Ámbito:** [Global](/guide/api-environment-plugins#hooks-por-entorno-y-hooks-globales)

  Modifica la configuración de Vite antes de que se resuelva. El enlace recibe la configuración de usuario sin procesar (las opciones de CLI se fusionaron con el archivo de configuración) y el entorno de configuración actual que expone el `mode` y el `command` que se están utilizando. Puede devolver un objeto de configuración parcial que se fusionará profundamente con la configuración existente, o mutar directamente la configuración (si la fusión predeterminada no puede lograr el resultado deseado).

  **Ejemplo:**

  ```js
  // devuelve la configuración parcial (recomendado)
  const partialConfigPlugin = () => ({
    name: 'return-partial',
    config: () => ({
      resolve: {
        alias: {
          foo: 'bar',
        },
      },
    }),
  })

  // muta la configuración directamente (usar solo cuando la fusión no funciona)
  const mutateConfigPlugin = () => ({
    name: 'mutate-config',
    config(config, { command }) {
      if (command === 'build') {
        config.root = 'foo'
      }
    },
  })
  ```

  ::: warning Nota
  Los plugins de usuario se resuelven antes de ejecutar este hook, por lo que inyectar otros plugins dentro del hook `config` no tendrá ningún efecto.
  :::

### `configResolved`

- **Tipo:** `(config: ResolvedConfig) => void | Promise<void>`
- **Clase:** `async`, `parallel`
- **Ámbito:** [Global](/guide/api-environment-plugins#hooks-por-entorno-y-hooks-globales)

  Se llama después de que se resuelve la configuración de Vite. Use este hook para leer y almacenar la configuración final resuelta. También es útil cuando el plugin necesita hacer algo diferente según el comando que se está ejecutando.

  **Ejemplo:**

  ```js
  const examplePlugin = () => {
    let config

    return {
      name: 'read-config',

      configResolved(resolvedConfig) {
        // store the resolved config
        config = resolvedConfig
      },

      // use stored config in other hooks
      transform(code, id) {
        if (config.command === 'serve') {
          // dev: plugin invoked by dev server
        } else {
          // build: plugin invoked by Rollup
        }
      },
    }
  }
  ```

  Ten en cuenta que el valor de `command` es `serve` en dev (en el CLI `vite`, `vite dev` y `vite serve` son alias).

### `configureServer`

- **Tipo:** `(server: ViteDevServer) => (() => void) | void | Promise<(() => void) | void>`
- **Clase:** `async`, `sequential`
- **Ámbito:** [Global](/guide/api-environment-plugins#hooks-por-entorno-y-hooks-globales)
- **Ver además:** [ViteDevServer](./api-javascript#vitedevserver)

  Hook para configurar el servidor dev. El caso de uso más común es agregar middlewares personalizados a la aplicación interna [connect](https://github.com/senchalabs/connect):

  ```js
  const myPlugin = () => ({
    name: 'configure-server',
    configureServer(server) {
      server.middlewares.use((req, res, next) => {
        // custom handle request...
      })
    },
  })
  ```

  **Inyección de middleware posterior**

  El enlace `configureServer` se llama antes de que se instalen los middlewares internos, por lo que los middlewares personalizados se ejecutarán antes que los middlewares internos de forma predeterminada. Si desea inyectar un middleware **después** de middlewares internos, puede devolver una función desde `configureServer`, que se llamará después de que se instalen los middlewares internos:

  ```js
  const myPlugin = () => ({
    name: 'configure-server',
    configureServer(server) {
      // devuelve un hook que se llama después de que los middlewares internos sean
      // instalados
      return () => {
        server.middlewares.use((req, res, next) => {
          // custom handle request...
        })
      }
    },
  })
  ```

  **Acceso de almacenamiento del servidor**

  En algunos casos, otros hooks de plugins pueden necesitar acceso a la instancia del servidor de desarrollo (por ejemplo, acceder al servidor de WebSocket, al observador del sistema de archivos o el gráfico del módulo). Este hook también se puede usar para almacenar la instancia del servidor para acceder a otros ganchos:

  ```js
  const myPlugin = () => {
    let server
    return {
      name: 'configure-server',
      configureServer(_server) {
        server = _server
      },
      transform(code, id) {
        if (server) {
          // use server...
        }
      },
    }
  }
  ```

  Ten en cuenta que `configureServer` no se llama cuando se ejecuta la compilación de producción, por lo que sus otros hooks deben protegerse contra su ausencia.

### `configurePreviewServer`

- **Tipo:** `(server: PreviewServer) => (() => void) | void | Promise<(() => void) | void>`
- **Clase:** `async`, `sequential`
- **Ámbito:** [Global](/guide/api-environment-plugins#hooks-por-entorno-y-hooks-globales)
- **Ver también:** [PreviewServer](./api-javascript#previewserver)

  Tal como [`configureServer`](/guide/api-plugin.html#configureserver) pero para el servidor de vista previa. De manera similar a `configureServer`, el hook `configurePreviewServer` se llama antes de que se instalen otros middlewares. Si deseas inyectar un middleware **después** de otros middlewares, puede devolver una función desde `configurePreviewServer`, que se llamará después de que se instalen los middlewares internos:

  ```js
  const myPlugin = () => ({
    name: 'configure-preview-server',
    configurePreviewServer(server) {
      // return a post hook that is called after other middlewares are
      // installed
      return () => {
        server.middlewares.use((req, res, next) => {
          // custom handle request...
        })
      }
    },
  })
  ```

### `closeServer`

- **Tipo:** `(context: { reason: 'restart' | 'close' }) => void | Promise<void>`
- **Clase:** `async`, `parallel`
- **Ámbito:** [Global](/guide/api-environment-plugins#hooks-por-entorno-y-hooks-globales)

  Se llama cuando el servidor de desarrollo se reinicia o se cierra, después de que el servidor ha sido desmontado. Normalmente se usa para liberar recursos creados en [`configureServer`](/guide/api-plugin.html#configureserver).

  `context.reason` distingue los dos casos:
  - `'restart'`: el servidor se está reiniciando (por ejemplo, un cambio en el archivo de configuración o una llamada a `server.restart()`).
  - `'close'`: el servidor se está cerrando (por ejemplo, el atajo `q` o una llamada a `server.close()`).

  ```js
  const myPlugin = () => {
    let resource
    return {
      name: 'close-server',
      configureServer(server) {
        resource = createResource()
      },
      async closeServer({ reason }) {
        if (reason === 'close') {
          await resource.dispose()
        }
      },
    }
  }
  ```

### `closePreviewServer`

- **Tipo:** `() => void | Promise<void>`
- **Clase:** `async`, `parallel`
- **Ámbito:** [Global](/guide/api-environment-plugins#hooks-por-entorno-y-hooks-globales)

  Igual que [`closeServer`](/guide/api-plugin.html#closeserver), pero para el servidor de vista previa. El servidor de vista previa nunca se reinicia, por lo que no se proporciona `reason`.

  ```js
  const myPlugin = () => {
    let resource
    return {
      name: 'close-preview-server',
      configurePreviewServer(server) {
        resource = createResource()
      },
      async closePreviewServer() {
        await resource.dispose()
      },
    }
  }
  ```

### `transformIndexHtml`

- **Tipo:** `IndexHtmlTransformHook | { order?: 'pre' | 'post', handler: IndexHtmlTransformHook }`
- **Clase:** `async`, `sequential`
- **Ámbito:** [Por entorno](/guide/api-environment-plugins#hooks-por-entorno-y-hooks-globales)

Hook dedicado para transformar archivos de punto de entrada HTML como `index.html`. El hook recibe la cadena HTML actual y un contexto de transformación. El contexto expone la instancia de [`ViteDevServer`](./api-javascript#vitedevserver) durante el desarrollo y expone el paquete de salida de Rollup durante la compilación.

El hook puede ser asíncrono y puede devolver uno de los siguientes:

- Cadena HTML transformada
- Un array de objetos de descriptores de etiquetas (`{ tag, attrs, children }`) para inyectarlos en el HTML existente. Cada etiqueta también puede especificar dónde debe inyectarse (por defecto se antepone a `<head>`)
- Un objeto que contiene ambos como `{ html, tags }`

Por defecto, `order` es `undefined`, con este hook aplicado después de transformar el HTML. Para poder inyectar un script que debería de pasar por el pipeline de los plugins de Vite, `order: 'pre'` aplicará el hook antes de procesar el HTML. `order: 'post'` Aplica el hook después de que se hayan aplicado todos los hooks con `order` undefined.

**Ejemplo básico:**

```js
const htmlPlugin = () => {
  return {
    name: 'html-transform',
    transformIndexHtml(html) {
      return html.replace(
        /<title>(.*?)<\/title>/,
        `<title>Title replaced!</title>`,
      )
    },
  }
}
```

**Firma de hook completa:**

```ts
type IndexHtmlTransformHook = (
  html: string,
  ctx: {
    path: string
    filename: string
    server?: ViteDevServer
    bundle?: import('rolldown').OutputBundle
    chunk?: import('rolldown').OutputChunk
    originalUrl?: string
  },
) => IndexHtmlTransformResult | void | Promise<IndexHtmlTransformResult | void>

type IndexHtmlTransformResult =
  | string
  | HtmlTagDescriptor[]
  | {
      html: string
      tags: HtmlTagDescriptor[]
    }

interface HtmlTagDescriptor {
  tag: string
  /**
   * los valores de los atributos se escaparán automáticamente si es necesario
   */
  attrs?: Record<string, string | boolean>
  children?: string | HtmlTagDescriptor[]
  /**
   * default: 'head-prepend'
   */
  injectTo?: 'head' | 'body' | 'head-prepend' | 'body-prepend'
}
```

:::warning Nota
Este hook no se invocará si estás utilizando un framework que tenga un manejo personalizado de los archivos de entrada (por ejemplo, [SvelteKit](https://github.com/sveltejs/kit/discussions/8269#discussioncomment-4509145)).
:::

### `handleHotUpdate`

- **Tipo:** `(ctx: HmrContext) => Array<ModuleNode> | void | Promise<Array<ModuleNode> | void>`
- **Clase:** `async`, `sequential`
- **Ámbito:** [Por entorno](/guide/api-environment-plugins#hooks-por-entorno-y-hooks-globales)
- **Ver tambien:** [HMR API](./api-hmr)

  Realiza el manejo personalizado de actualizaciones de HMR. El hook recibe un objeto de contexto con la siguiente firma:

  ```ts
  interface HmrContext {
    file: string
    timestamp: number
    modules: Array<ModuleNode>
    read: () => string | Promise<string>
    server: ViteDevServer
  }
  ```

  - `modules` es un array de módulos que se ven afectados por el archivo modificado. Es un array porque un solo archivo puede asignarse a múltiples módulos servidos (por ejemplo, Vue SFC).

  - `read` es una función de lectura asíncrona que devuelve el contenido del archivo. Esto se proporciona porque en algunos sistemas, la devolución de llamada de cambio de archivo puede activarse demasiado rápido antes de que el editor termine de actualizar el archivo y `fs.readFile` directo devolverá contenido vacío. La función de lectura pasada normaliza este comportamiento.

  El hook puede optar por:
  - Filtrar y reducir la lista de módulos afectados para que el HMR sea más preciso.

  - Devolver un array vacío y realizar una recarga completa:

  ```js
    handleHotUpdate({ server, modules, timestamp }) {
      const invalidatedModules = new Set()
      for (const mod of modules) {
        server.moduleGraph.invalidateModule(
          mod,
          invalidatedModules,
          timestamp,
          true
        )
      }
      server.hot.send({ type: 'full-reload' })
      return []
    }
  ```

  - Devolver un array vacío y realizar un manejo personalizado completo de HMR enviando eventos personalizados al cliente:

  ```js
  handleHotUpdate({ server }) {
    server.hot.send({
      type: 'custom',
      event: 'special-update',
      data: {}
    })
    return []
  }
  ```

  El código del cliente debe registrar el controlador correspondiente utilizando la [API HMR](./api-hmr) (esto podría inyectarse mediante el hook `transform` del mismo plugin):

  ```js
  if (import.meta.hot) {
    import.meta.hot.on('special-update', (data) => {
      // perform custom update
    })
  }
  ```

## Contexto Meta del Plugin

Para los hooks de plugins que tienen acceso al contexto del plugin, Vite expone propiedades adicionales en `this.meta`:

- `this.meta.viteVersion`: La versión actual de Vite como string (por ejemplo, `"8.0.0"`).

::: tip Detectando si Vite usa Rolldown

[`this.meta.rolldownVersion`](https://rolldown.rs/reference/Interface.PluginContextMeta#rolldownversion) solo está disponible para una versión de Vite potenciada por Rolldown (es decir, Vite 8+). Puedes usarlo para detectar si la instancia actual de Vite está siendo impulsada por Rolldown:

```ts
function versionCheckPlugin(): Plugin {
  return {
    name: 'version-check',
    buildStart() {
      if (this.meta.rolldownVersion) {
        // solo haz algo si se ejecuta en un Vite potenciado por Rolldown
      } else {
        // haz algo más si se ejecuta en un Vite potenciado por Rollup
      }
    },
  }
}
```

:::

## Metadatos del Paquete de Salida

Durante la compilación, Vite agrega un campo específico `viteMetadata` a los objetos de salida de compilación de Rolldown.

Esto está disponible a través de:

- `RenderedChunk` (por ejemplo en `renderChunk` y `augmentChunkHash`)
- `OutputChunk` y `OutputAsset` (por ejemplo en `generateBundle` y `writeBundle`)

`viteMetadata` proporciona:

- `viteMetadata.importedCss: Set<string>`
- `viteMetadata.importedAssets: Set<string>`

Esto es útil cuando se escriben plugins que necesitan inspeccionar CSS emitidos y recursos estáticos sin depender de [`build.manifest`](/config/build-options#build-manifest).

Ejemplo:

```ts [vite.config.ts]
function outputMetadataPlugin(): Plugin {
  return {
    name: 'output-metadata-plugin',
    enforce: 'post',
    generateBundle(_, bundle) {
      for (const output of Object.values(bundle)) {
        const css = output.viteMetadata?.importedCss
        const assets = output.viteMetadata?.importedAssets
        if (!css?.size && !assets?.size) continue

        console.log(output.fileName, {
          css: css ? [...css] : [],
          assets: assets ? [...assets] : [],
        })
      }
    },
  }
}
```

## Orden de Plugins

Un plugin de Vite también puede especificar una propiedad `enforce` (similar a los cargadores de paquetes web) para ajustar su orden de aplicación. El valor de `enforce` puede ser `"pre"` o `"post"`. Los plugins resueltos estarán en el siguiente orden:

- Alias
- Plugins de usuario con `enforce: 'pre'`
- Plugins principales de Vite
- Plugins de usuario sin valor enforce
- Plugins de compilación de Vite
- Plugins de usuario con `enforce: 'post'`
- Plugins de compilación de publicaciones de Vite (minify, manifest, reporting)

Es importante tener en cuenta que esto es independiente del ordenamiento de los hooks, los cuales siguen estando sujetos por separado a su atributo `order` [como es habitual en los hooks de Rolldown](https://rolldown.rs/reference/TypeAlias.ObjectHook#order).

## Solicitud Condicional

Por defecto, los plugins se invocan tanto para servir como para compilar. En los casos en que un plugin deba aplicarse condicionalmente solo durante el servicio o la compilación, use la propiedad `apply` para invocarlos solo durante la `'build'` o `'serve'`:

```js
function myPlugin() {
  return {
    name: 'build-only',
    apply: 'build', // or 'serve'
  }
}
```

También se puede utilizar una función para un control más preciso:

```js
apply(config, { command }) {
  // apply only on build but not for SSR
  return command === 'build' && !config.build.ssr
}
```

## Compatibilidad de Plugins Rolldown

Una buena cantidad de plugins de Rolldown / Rollup funcionarán directamente como un plugin de Vite (por ejemplo, `@rollup/plugin-alias` o `@rollup/plugin-json`), pero no todos, ya que algunos hooks de plugin no tienen sentido en un contexto de servidor de desarrollo desacoplado.

En general, siempre que un plugin de Rolldown / Rollup cumpla con los siguientes criterios, debería funcionar como un plugin de Vite:

- No utiliza el hook [`moduleParsed`](https://rolldown.rs/reference/Interface.Plugin#moduleparsed).
- No depende de las opciones específicas de Rolldown como [`transform.inject`](https://rolldown.rs/reference/InputOptions.transform#inject)
- No tiene un fuerte acoplamiento entre los hooks de fase de entrada y los hooks de fase de salida.

Si un plugin de Rolldown / Rollup solo tiene sentido para la fase de compilación, entonces se puede especificar en `build.rolldownOptions.plugins`. Funcionará igual que un plugin de Vite con `enforce: 'post'` y `apply: 'build'`.

También puede aumentar un plugin de Rolldown / Rollup existente con propiedades exclusivas de Vite:

```js [vite.config.js]
import example from 'rolldown-plugin-example'
import { defineConfig } from 'vite'

export default defineConfig({
  plugins: [
    {
      ...example(),
      enforce: 'post',
      apply: 'build',
    },
  ],
})
```

Consulta [Vite Rollup Plugins](https://vite-rollup-plugins.patak.dev) para obtener una lista de plugins oficiales de rollup compatibles con instrucciones de uso.

## Referencia a Recursos Emitidos

Para emitir un recurso desde un plugin, llama a [`this.emitFile({ type: 'asset', ... })`](https://rolldown.rs/reference/Interface.PluginContext#in-depth-type-asset). Devuelve un `referenceId` que puedes usar para generar la URL del recurso, ya que su nombre de archivo final no se conoce hasta que se genera el bundle.

### En JavaScript

Usa `import.meta.ROLLDOWN_FILE_URL_<referenceId>`:

```js
const referenceId = this.emitFile({
  type: 'asset',
  name: 'icon.png',
  source: fileContent,
})

// es una expresión JavaScript, así que añade cualquier query o hash con concatenación de cadenas
return `export default import.meta.ROLLDOWN_FILE_URL_${referenceId} + '#frag'`
```

### En CSS o HTML

`import.meta.ROLLDOWN_FILE_URL_<referenceId>` solo funciona en posiciones de expresiones JavaScript. En CSS o HTML, usa el token `__VITE_ASSET__<referenceId>__` en su lugar, añadiendo cualquier query o hash justo después:

```css
background: url(__VITE_ASSET__<referenceId>__#frag);
```

## Normalización de Rutas

Vite normaliza las rutas mientras resuelve las identificaciones para usar los separadores POSIX (/) mientras conserva el volumen en Windows. Por otro lado, Rollup mantiene intactas las rutas resueltas de manera predeterminada, por lo que las identificaciones resueltas tienen separadores win32 ( \\ ) en Windows. Sin embargo, los plugins de Rollup utilizan una [función de utilidad `normalizePath`](https://github.com/rollup/plugins/tree/master/packages/pluginutils#normalizepath) de `@rollup/pluginutils` internamente, que convierte los separadores en POSIX antes de realizar comparaciones. Esto significa que cuando estos plugins se usan en Vite, el patrón de configuración `include` y `exclude` y otras rutas similares contra las comparaciones de identificadores resueltos funcionan correctamente.

Por lo tanto, para los plugins de Vite, al comparar rutas con identificadores resueltos, es importante normalizar primero las rutas para usar separadores POSIX. Una función de utilidad `normalizePath` equivalente se exporta desde el módulo `vite`.

```js
import { normalizePath } from 'vite'

normalizePath('foo\\bar') // 'foo/bar'
normalizePath('foo/bar') // 'foo/bar'
```

## Filtrado, Patrón include/exclude

Vite expone la función `createFilter` de [`@rollup/pluginutils`](https://github.com/rollup/plugins/tree/master/packages/pluginutils#createfilter) para alentar a los plugins e integraciones específicos de Vite a usar el patrón de filtrado estándar include/exclude, que también se utiliza en el propio núcleo de Vite.

### Filtros de Hooks

Rolldown introdujo una [característica de filtro de hooks](https://rolldown.rs/apis/plugin-api/hook-filters) para reducir la sobrecarga de comunicación entre los entornos de ejecución de Rust y JavaScript. Esta característica permite que los plugins especifiquen patrones que determinan cuándo deben llamarse los hooks, mejorando el rendimiento al evitar invocaciones innecesarias.

Esta funcionalidad también es compatible con Rollup 4.38.0+ y Vite 6.3.0+. Para hacer que tu plugin sea compatible con versiones anteriores, asegúrate de ejecutar el filtro también dentro de los controladores de los hooks.

```js
export default function myPlugin() {
  const jsFileRegex = /\.js$/

  return {
    name: 'my-plugin',
    // Ejemplo: solo llamar a transform para archivos .js
    transform: {
      filter: {
        id: jsFileRegex,
      },
      handler(code, id) {
        // Comprobación adicional para compatibilidad hacia atrás
        if (!jsFileRegex.test(id)) return null

        return {
          code: transformCode(code),
          map: null,
        }
      },
    },
  }
}
```

::: tip
[`@rolldown/pluginutils`](https://www.npmjs.com/package/@rolldown/pluginutils) exporta algunas utilidades para filtros de hooks como `exactRegex` y `prefixRegex`. Estas también se re-exportan desde `rolldown/filter` por conveniencia.
:::

## Información de mapas de importación de fragmentos

:::info Experimental

Esta funcionalidad es experimental y puede cambiar en el futuro.

:::

Cuando la opción [`build.chunkImportMap`](/config/build-options#build-chunkimportmap) está habilitada, las declaraciones de importación en los fragmentos generados usarán un ID único para cada fragmento en lugar de la ruta del archivo.

Para obtener el mapeo del ID del fragmento a la ruta del archivo, puedes acceder al mapa de importación emitido para el bundle en el hook `generateBundle` o en el hook `writeBundle`. El mapa de importación tiene el nombre especificado por [`build.rolldownOptions.experimental.chunkImportMap.fileName`](https://rolldown.rs/reference/InputOptions.experimental#chunkimportmap) (por defecto es `importmap.json`).

```ts
function accessImportMap() {
  let config: ResolvedConfig
  return {
    name: 'access-import-map',
    configResolved(resolvedConfig) {
      config = resolvedConfig
    },
    generateBundle(options, bundle) {
      const chunkImportMap =
        config.build.rolldownOptions.experimental?.chunkImportMap
      if (chunkImportMap) {
        const importMapFilename =
          typeof chunkImportMap === 'object' && chunkImportMap.fileName
            ? chunkImportMap.fileName
            : 'importmap.json'
        const importMap = bundle[importMapFilename]! as OutputAsset
        const mapping = JSON.parse(importMap.source).imports
        console.log(mapping)
        // { "./entry.hash1.js": "./entry.hash2.js" }
      }
    },
  }
}
```

## Comunicación Cliente-Servidor

Desde Vite 2.9, proporcionamos algunas utilidades para plugins que ayudan a manejar la comunicación con los clientes.

### Servidor a Cliente

En el lado del plugin, podríamos usar `server.hot.send` para transmitir eventos al cliente:

```js [vite.config.js]
export default defineConfig({
  plugins: [
    {
      // ...
      configureServer(server) {
        server.ws.on('connection', () => {
          server.hot.send('my:greetings', { msg: 'hello' })
        })
      },
    },
  ],
})
```

::: tip NOTA
Recomendamos **siempre prefijar** los nombres de tus eventos para evitar colisiones con otros plugins.
:::

En el lado del cliente, usa [`hot.on`](/guide/api-hmr.html#hot-on-event-cb) para escuchar los eventos:

```ts twoslash
import 'vite/client'
// ---cut---
// client side
if (import.meta.hot) {
  import.meta.hot.on('my:greetings', (data) => {
    console.log(data.msg) // hello
  })
}
```

### Cliente a Servidor

Para enviar eventos del cliente al servidor, podemos usar [`hot.send`](/guide/api-hmr.html#hot-send-event-data):

```ts
// client side
if (import.meta.hot) {
  import.meta.hot.send('my:from-client', { msg: 'Hey!' })
}
```

Luego usa `server.hot.on` y así escuchar los eventos en el lado del servidor:

```js [vite.config.js]
export default defineConfig({
  plugins: [
    {
      // ...
      configureServer(server) {
        server.hot.on('my:from-client', (data, client) => {
          console.log('Message from client:', data.msg) // Hey!
          // reply only to the client (if needed)
          client.send('my:ack', { msg: 'Hi! I got your message!' })
        })
      },
    },
  ],
})
```

### TypeScript para Eventos Personalizados

Internamente, Vite infiere el tipo de un payload a partir de la interfaz `CustomEventMap`, por lo que es posible tipar eventos personalizados mediante la extensión de la interfaz:

:::tip Nota
Asegúrate de incluir la extensión `.d.ts` al especificar archivos de declaración TypeScript. De lo contrario, TypeScript puede que no sepa qué archivo está intentando extender el módulo.
:::

```ts [events.d.ts]
import 'vite/types/customEvent.d.ts'

declare module 'vite/types/customEvent.d.ts' {
  interface CustomEventMap {
    'custom:foo': { msg: string }
    // 'event-key': payload
  }
}
```

Esta extensión de interfaz es utilizada por `InferCustomEventPayload<T>` para inferir el tipo de payload para el evento `T`. Para obtener más información sobre cómo se utiliza esta interfaz, consulta la [Documentación de la API de HMR](./api-hmr#hmr-api).

```ts twoslash
import 'vite/client'
import type { InferCustomEventPayload } from 'vite/types/customEvent.d.ts'
declare module 'vite/types/customEvent.d.ts' {
  interface CustomEventMap {
    'custom:foo': { msg: string }
  }
}
// ---cut---
type CustomFooPayload = InferCustomEventPayload<'custom:foo'>
import.meta.hot?.on('custom:foo', (payload) => {
  // El tipo de payload será { msg: string }
})
import.meta.hot?.on('unknown:event', (payload) => {
  // El tipo de payload será any
})
```
