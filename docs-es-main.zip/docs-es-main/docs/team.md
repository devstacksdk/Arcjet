---
layout: page
title: Conoce al Equipo
description: El desarrollo de Vite está guiado por un equipo de talla internacional.
---

<script setup>
import {
  VPTeamPage,
  VPTeamPageTitle,
  VPTeamPageSection,
  VPTeamMembers
} from '@voidzero-dev/vitepress-theme'
import { core, advisors, emeriti } from './_data/team'
</script>

<VPTeamPage>
  <VPTeamPageTitle>
    <template #title>Conoce al Equipo</template>
    <template #lead>
      El desarrollo de Vite está guiado por un equipo de talla internacional, algunos de los cuales han sido elegidos para aparecer a continuación.
    </template>
  </VPTeamPageTitle>
  <VPTeamMembers :members="core" />
  <VPTeamPageSection>
    <template #title>Asesores</template>
    <template #lead>
      Los asesores ayudan a guiar a Vite desde el ecosistema, compartiendo su
      experiencia para dar forma a la Environment API y al diseño de futuras APIs.
    </template>
    <template #members>
      <VPTeamMembers size="small" :members="advisors" />
    </template>
  </VPTeamPageSection>
  <VPTeamPageSection>
    <template #title>Team Emeriti</template>
    <template #lead>
      Aquí destacamos a algunos miembros del equipo que ya no están activos y que han hecho valiosas
      contribuciones en el pasado.
    </template>
    <template #members>
      <VPTeamMembers size="small" :members="emeriti" />
    </template>
  </VPTeamPageSection>
</VPTeamPage>
