import path from 'node:path'
import fs from 'node:fs'
import type { HeadConfig } from 'vitepress'
import { defineConfig } from 'vitepress'
import { transformerTwoslash } from '@shikijs/vitepress-twoslash'
import {
  groupIconMdPlugin,
  groupIconVitePlugin,
} from 'vitepress-plugin-group-icons'
import { graphvizMarkdownPlugin } from 'vitepress-plugin-graphviz'
import { extendConfig } from '@voidzero-dev/vitepress-theme/config'
import type { FooterLink } from '@voidzero-dev/vitepress-theme'
import { buildEnd } from './buildEnd.config.ts'

const viteVersion = JSON.parse(
  fs.readFileSync(path.resolve(import.meta.dirname, '../../package.json'), 'utf-8'),
).dependencies.vite.replace(/[^0-9.]/g, '')
const viteMajorVersion = +viteVersion.split('.')[0]

const ogDescription = 'Herramienta de compilación frontend de próxima generación'
const ogImage = 'https://es.vite.dev/og-image.jpg'
const ogTitle = 'Vite'
const ogUrl = 'https://es.vite.dev'

// netlify envs
const deployURL = process.env.DEPLOY_PRIME_URL || ''
const commitRef = process.env.COMMIT_REF?.slice(0, 8) || 'dev'

const deployType = (() => {
  switch (deployURL) {
    case 'https://main--vite-docs-main.netlify.app':
      return 'main'
    case '':
      return 'local'
    default:
      return 'release'
  }
})()
const additionalTitle = ((): string => {
  switch (deployType) {
    case 'main':
      return ' (rama principal)'
    case 'local':
      return ' (local)'
    case 'release':
      return ''
  }
})()
const versionLinks = (() => {
  const links: FooterLink[] = []

  if (deployType !== 'main') {
    links.push({
      text: 'Docs no lanzadas',
      link: 'https://main.vite.dev',
    })
  }

  if (deployType === 'main' || deployType === 'local') {
    links.push({
      text: `Docs de Vite ${viteMajorVersion} (lanzamiento)`,
      link: 'https://vite.dev',
    })
  }

  // Create version links from v2 onwards
  for (let i = viteMajorVersion - 1; i >= 2; i--) {
    links.push({
      text: `Docs de Vite ${i}`,
      link: `https://v${i}.vite.dev`,
    })
  }

  return links
})()


const config = defineConfig({
  lang: 'es',
  title: `Vite${additionalTitle}`,
  description: 'Herramienta de compilación frontend de próxima generación',
  cleanUrls: true,
  sitemap: {
    hostname: 'https://es.vite.dev',
  },
  head: [
    [
      'link',
      { rel: 'icon', type: 'image/svg+xml', href: '/logo-without-border.svg' },
    ],
    [
      'link',
      { rel: 'alternate', type: 'application/rss+xml', href: '/blog.rss' },
    ],
    ['link', { rel: 'preconnect', href: 'https://fonts.googleapis.com' }],

    ['link', { rel: 'me', href: 'https://m.webtoo.ls/@vite' }],
    ['meta', { property: 'og:type', content: 'website' }],
    ['meta', { property: 'og:title', content: ogTitle }],
    ['meta', { property: 'og:image', content: ogImage }],
    ['meta', { property: 'og:url', content: ogUrl }],
    ['meta', { property: 'og:description', content: ogDescription }],
    ['meta', { property: 'og:site_name', content: 'vitejs' }],
    ['meta', { name: 'twitter:card', content: 'summary_large_image' }],
    ['meta', { name: 'twitter:site', content: '@vite_js' }],
    ['meta', { name: 'theme-color', content: '#646cff' }],
  ],

  locales: {
    root: { label: 'Español' },
    en: { label: 'English', link: 'https://vite.dev' },
    zh: { label: '简体中文', link: 'https://cn.vite.dev' },
    ja: { label: '日本語', link: 'https://ja.vite.dev' },
    ko: { label: '한국어', link: 'https://ko.vite.dev' },
    de: { label: 'Deutsch', link: 'https://de.vite.dev' },
  },

  themeConfig: {
    variant: 'vite',
    banner: {
      id: 'cloudflare-supports-vite',
      text: `Cloudflare apoya la misión de Vite`,
      url: '/blog/cloudflare-supports-vite',
    },

    editLink: {
      pattern: 'https://github.com/vitejs/docs-es/edit/main/docs/:path',
      text: 'Sugerir cambios para esta página',
    },

    socialLinks: [
      { icon: 'bluesky', link: 'https://bsky.app/profile/vite.dev' },
      { icon: 'mastodon', link: 'https://elk.zone/m.webtoo.ls/@vite' },
      { icon: 'x', link: 'https://x.com/vite_js' },
      { icon: 'discord', link: 'https://chat.vite.dev' },
      { icon: 'github', link: 'https://github.com/vitejs/vite' },
    ],
    darkModeSwitchLabel: 'Apariencia',
    search: {
      provider: 'local',
      options: {
        translations: {
          button: {
            buttonText: 'Buscar',
            buttonAriaLabel: 'Buscar',
          },
          modal: {
            displayDetails: 'Mostrar vista detallada',
            resetButtonTitle: 'Limpiar búsqueda',
            backButtonTitle: 'Cerrar búsqueda',
            noResultsText: 'No se encontraron resultados para',
            footer: {
              selectText: 'seleccionar',
              navigateText: 'navegar',
              closeText: 'cerrar',
            },
          },
        },
        miniSearch: {
          searchOptions: {
            boostDocument(page) {
              if (page.startsWith('/guide/')) return 2 // Preferir páginas de guía
              if (page.startsWith('/config/')) return 1.5 // Luego páginas de configuración
              if (page.startsWith('/blog/')) return 0 // No indexar publicaciones del blog
              return 1
            },
          },
        },
      },
    },

    carbonAds: {
      code: 'CEBIEK3N',
      placement: 'vitejsdev',
    },

    outlineTitle: 'En esta página',
    docFooter: {
      prev: 'Página anterior',
      next: 'Próxima página',
    },

    footer: {
      copyright: `2019-presente VoidZero Inc. y Colaboradores de Vite. (${commitRef})`,
      nav: [
        {
          title: 'Vite',
          items: [
            { text: 'Guía', link: '/guide/' },
            { text: 'Configuración', link: '/config/' },
            { text: 'Plugins', link: '/plugins/' },
          ],
        },
        {
          title: 'Recursos',
          items: [
            { text: 'Equipo', link: '/team' },
            { text: 'Blog', link: '/blog' },
            {
              text: 'Lanzamientos',
              link: 'https://github.com/vitejs/vite/releases',
            },
            { text: 'Agradecimientos', link: '/acknowledgements' },
          ],
        },
        {
          title: 'Versiones',
          items: versionLinks,
        },
      ],
      social: [
        { icon: 'github', link: 'https://github.com/vitejs/vite' },
        { icon: 'discord', link: 'https://chat.vite.dev' },
        { icon: 'bluesky', link: 'https://bsky.app/profile/vite.dev' },
        { icon: 'x', link: 'https://x.com/vite_js' },
      ],
    },

    nav: [
      { text: 'Guía', link: '/guide/', activeMatch: '/guide/' },
      { text: 'Configuración', link: '/config/', activeMatch: '/config/' },
      { text: 'Plugins', link: '/plugins/', activeMatch: '/plugins/' },
      {
        text: 'Recursos',
        items: [
          { text: 'Equipo', link: '/team' },
          { text: 'Blog', link: '/blog' },
          { text: 'Lanzamientos', link: '/releases' },
          {
            text: 'Agradecimientos',
            link: '/acknowledgements',
          },
          {
            text: 'Código de Conducta',
            link: 'https://github.com/vitejs/.github/blob/main/CODE_OF_CONDUCT.md',
          },
          {
            text: 'Escenario en Vivo',
            link: '/live',
          },
          {
            text: 'El Documental',
            link: 'https://www.youtube.com/watch?v=bmWQqAKLgT4',
          },
          {
            items: [
              {
                text: 'Bluesky',
                link: 'https://bsky.app/profile/vite.dev',
              },
              {
                text: 'Mastodon',
                link: 'https://elk.zone/m.webtoo.ls/@vite',
              },
              {
                text: 'X',
                link: 'https://x.com/vite_js',
              },
              {
                text: 'Chat de Discord',
                link: 'https://chat.vite.dev',
              },
              {
                text: 'Awesome Vite',
                link: 'https://github.com/vitejs/awesome-vite',
              },
              {
                text: 'ViteConf',
                link: 'https://viteconf.org',
              },
              {
                text: 'DEV Community',
                link: 'https://dev.to/t/vite',
              },
              {
                text: 'Lista de Cambios',
                link: 'https://github.com/vitejs/vite/blob/main/packages/vite/CHANGELOG.md',
              },
              {
                text: 'Contribución',
                link: 'https://github.com/vitejs/docs-es/blob/main/CONTRIBUTING.md',
              },
            ],
          },
        ],
      },
      {
        text: `v${viteVersion}`,
        items: [
          {
            text: 'Lista de Cambios',
            link: 'https://github.com/vitejs/vite/blob/main/packages/vite/CHANGELOG.md',
          },
          {
            text: 'Contribución',
            link: 'https://github.com/vitejs/docs-es/blob/main/CONTRIBUTING.md',
          },
          {
            items: versionLinks,
          },
        ],
      },
    ],

    sidebar: {
      '/guide/': [
        {
          text: 'Introducción',
          items: [
            {
              text: 'Introducción',
              link: '/guide/',
            },
            {
              text: 'Filosofía',
              link: '/guide/philosophy',
            },
            {
              text: '¿Por qué Vite?',
              link: '/guide/why',
            },
          ],
        },
        {
          text: 'Guía',
          items: [
            {
              text: 'Funcionalidades',
              link: '/guide/features',
            },
            {
              text: 'Interfaz de línea de comandos',
              link: '/guide/cli',
            },
            {
              text: 'Uso de plugins',
              link: '/guide/using-plugins',
            },
            {
              text: 'Preempaquetado de dependencias',
              link: '/guide/dep-pre-bundling',
            },
            {
              text: 'Gestión de recursos estáticos',
              link: '/guide/assets',
            },
            {
              text: 'Compilación para producción',
              link: '/guide/build',
            },
            {
              text: 'Despliegue de un sitio estático',
              link: '/guide/static-deploy',
            },
            {
              text: 'Variables y modos de entorno',
              link: '/guide/env-and-mode',
            },
            {
              text: 'Server-side Rendering (SSR)',
              link: '/guide/ssr',
            },
            {
              text: 'Integración al Backend',
              link: '/guide/backend-integration',
            },
            // {
            //   text: 'Comparaciones',
            //   link: '/guide/comparisons',
            // },
            {
              text: 'Solución de problemas',
              link: '/guide/troubleshooting',
            },
            {
              text: 'Rendimiento',
              link: '/guide/performance',
            },
            // {
            //   text: 'Migración desde v2',
            //   link: '/guide/migration-v2-to-v3',
            // },
            // {
            //   text: 'Migración desde v3',
            //   link: '/guide/migration-v3-to-v4',
            // },
            // {
            //   text: 'Migración desde v4',
            //   link: '/guide/migration-v4-to-v5',
            // },
            {
              text: 'Rolldown',
              link: '/guide/rolldown',
            },
            {
              text: `Migración desde v${viteMajorVersion}`,
              link: '/guide/migration',
            },
            {
              text: 'Cambios importantes',
              link: '/changes/',
            },
          ],
        },
        {
          text: 'APIs',
          items: [
            {
              text: 'API de plugins',
              link: '/guide/api-plugin',
            },
            {
              text: 'API de HMR',
              link: '/guide/api-hmr',
            },
            {
              text: 'API de JavaScript',
              link: '/guide/api-javascript',
            },
            {
              text: 'Referencia de Configuración',
              link: '/config/',
            },
          ],
        },
        {
          text: 'API de Entorno',
          items: [
            {
              text: 'Introducción',
              link: '/guide/api-environment',
            },
            {
              text: 'Instancias de Entorno',
              link: '/guide/api-environment-instances',
            },
            {
              text: 'Plugins',
              link: '/guide/api-environment-plugins',
            },
            {
              text: 'Frameworks',
              link: '/guide/api-environment-frameworks',
            },
            {
              text: 'Runtimes',
              link: '/guide/api-environment-runtimes',
            },
          ],
        },
      ],
      '/config/': [
        {
          text: 'Configuración',
          items: [
            {
              text: 'Configurando Vite',
              link: '/config/',
            },
            {
              text: 'Opciones compartidas',
              link: '/config/shared-options',
            },
            {
              text: 'Opciones para server',
              link: '/config/server-options',
            },
            {
              text: 'Opciones para build',
              link: '/config/build-options',
            },
            {
              text: 'Opciones para preview',
              link: '/config/preview-options',
            },
            {
              text: 'Opciones para optimización de dependencias',
              link: '/config/dep-optimization-options',
            },
            {
              text: 'Opciones para SSR',
              link: '/config/ssr-options',
            },
            {
              text: 'Opciones para Worker',
              link: '/config/worker-options',
            },
          ],
        },
      ],
      '/changes/': [
        {
          text: 'Cambios importantes',
          link: '/changes/',
        },
        {
          text: 'Actual',
          items: [],
        },
        {
          text: 'Futuro',
          items: [
            {
              text: 'this.environment en Hooks',
              link: '/changes/this-environment-in-hooks',
            },
            {
              text: 'Hooks de Plugin HotUpdate para HMR',
              link: '/changes/hotupdate-hook',
            },
            {
              text: 'Migración a APIs por Entorno',
              link: '/changes/per-environment-apis',
            },
            {
              text: 'SSR Usando la API ModuleRunner',
              link: '/changes/ssr-using-modulerunner',
            },
            {
              text: 'Plugins Compartidos Durante la Compilación',
              link: '/changes/shared-plugins-during-build',
            },
          ],
        },
        {
          text: 'Pasado',
          items: [],
        },
      ],
    },
    outline: {
      level: [2, 3],
    },
  },
  transformHead(ctx) {
    const path = ctx.page.replace(/(^|\/)index\.md$/, '$1').replace(/\.md$/, '')

    if (path !== '404') {
      const canonicalUrl = path ? `${ogUrl}/${path}` : ogUrl
      ctx.head.push(
        ['link', { rel: 'canonical', href: canonicalUrl }],
        ['meta', { property: 'og:title', content: ctx.pageData.title }],
      )
    }

    // For the landing page, move the google font links to the top for better performance
    if (path === '') {
      const googleFontLinks: HeadConfig[] = []
      for (let i = 0; i < ctx.head.length; i++) {
        const tag = ctx.head[i]
        if (
          tag[0] === 'link' &&
          (tag[1]?.href?.includes('fonts.googleapis.com') ||
            tag[1]?.href?.includes('fonts.gstatic.com'))
        ) {
          ctx.head.splice(i, 1)
          googleFontLinks.push(tag)
          i--
        }
      }
      ctx.head.unshift(...googleFontLinks)
    }
  },
  markdown: {
    // languages used for twoslash and jsdocs in twoslash
    languages: ['ts', 'js', 'json'],
    codeTransformers: [
      transformerTwoslash({
        twoslashOptions: {
          compilerOptions: {
            moduleResolution: 100, // bundler
            ignoreDeprecations: '6.0', // remove the options entirely when twoslash doesn't set `baseUrl`
          },
        },
      }),
      // add `style:*` support
      {
        root(hast) {
          const meta = this.options.meta?.__raw
            ?.split(' ')
            .find((m) => m.startsWith('style:'))
          if (meta) {
            const style = meta.slice('style:'.length)
            const rootPre = hast.children.find(
              (n): n is typeof n & { type: 'element'; tagName: 'pre' } =>
                n.type === 'element' && n.tagName === 'pre',
            )
            if (rootPre) {
              rootPre.properties.style += '; ' + style
            }
          }
        },
      },
    ],
    async config(md) {
      md.use(groupIconMdPlugin, {
        titleBar: {
          includeSnippet: true,
        },
      })
      await graphvizMarkdownPlugin(md)
    },
  },
  vite: {
    resolve: {
      alias: {
        '@components/oss/TopBanner.vue': path.resolve(
          import.meta.dirname,
          'theme/components/TopBanner.vue',
        ),
      },
    },
    build: {
      chunkSizeWarningLimit: 2000
    },
    plugins: [
      // @ts-expect-error: Vite 8 (project) vs Vite 7 (VitePress) PluginContextMeta type conflict
      groupIconVitePlugin({
        customIcon: {
          firebase: 'vscode-icons:file-type-firebase',
          '.gitlab-ci.yml': 'vscode-icons:file-type-gitlab',
        },
      }),
    ],
    optimizeDeps: {
      include: ['@shikijs/vitepress-twoslash/client'],
    },
    define: {
      __VITE_VERSION__: JSON.stringify(viteVersion),
    },
  },
  buildEnd,
})

export default extendConfig(config)
