import('./lazy.js')
